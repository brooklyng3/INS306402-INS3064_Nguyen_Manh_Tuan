<?php
require_once 'Database.php';

$db = Database::getInstance()->getConnection();

// 1. Fetch categories for the filter dropdown
$catSql = "SELECT id, category_name FROM categories ORDER BY category_name";
$categories = $db->query($catSql)->fetchAll();

// 2. Capture search inputs
$searchName = $_GET['search'] ?? '';
$searchCategory = $_GET['category_id'] ?? '';

// 3. Build the dynamic SQL query
// Using a LEFT JOIN ensures products without a category (like the 'Uncategorized Widget') are still displayed
$sql = "SELECT p.id, p.name, p.price, p.stock, c.category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE 1=1"; 

$params = [];

if (!empty($searchName)) {
    $sql .= " AND p.name LIKE :search_name";
    $params[':search_name'] = "%" . $searchName . "%";
}

if (!empty($searchCategory)) {
    $sql .= " AND p.category_id = :category_id";
    $params[':category_id'] = $searchCategory;
}

$sql .= " ORDER BY p.id";

// 4. Prepare and Execute (PDO Integrity)
$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Admin Dashboard</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #f4f4f4; }
        .low-stock { background-color: #ffebee; color: #c62828; font-weight: bold; }
        .filter-form { margin-bottom: 20px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; }
    </style>
</head>
<body>

    <h2>Product Administration Dashboard</h2>

    <div class="filter-form">
        <form method="GET" action="index.php">
            <label for="search">Product Name:</label>
            <input type="text" name="search" id="search" placeholder="Search by name..." 
                   value="<?= htmlspecialchars($searchName) ?>">

            <label for="category_id">Category:</label>
            <select name="category_id" id="category_id">
                <option value="">-- All Categories --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= htmlspecialchars($cat['id']) ?>" 
                        <?= $searchCategory == $cat['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Filter</button>
            <a href="index.php"><button type="button">Reset</button></a>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $product): ?>
                    <?php 
                        $rowClass = ($product['stock'] < 10) ? 'low-stock' : ''; 
                    ?>
                    <tr class="<?= $rowClass ?>">
                        <td><?= htmlspecialchars($product['id']) ?></td>
                        <td><?= htmlspecialchars($product['name']) ?></td>
                        <td><?= htmlspecialchars($product['category_name'] ?? 'Uncategorized') ?></td>
                        <td><?= number_format($product['price'], 2) ?> VND</td>
                        <td><?= htmlspecialchars($product['stock']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center;">No products found matching your criteria.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>