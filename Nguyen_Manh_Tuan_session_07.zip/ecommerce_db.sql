-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2026 at 09:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`) VALUES
(1, 'Electronics'),
(2, 'Clothing'),
(3, 'Books'),
(4, 'Home & Garden'),
(5, 'Sports'),
(6, 'Red Team Gear');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_date`, `total_amount`) VALUES
(1, 1, '2026-03-28 08:53:37', 15500000.00),
(2, 2, '2026-03-28 08:53:37', 450000.00),
(3, 7, '2026-03-28 08:53:37', 1200000.00),
(4, 3, '2026-03-28 08:53:37', 2500000.00),
(5, 4, '2026-03-28 08:53:37', 350000.00),
(6, 5, '2026-03-28 08:53:37', 850000.00),
(7, 6, '2026-03-28 08:53:37', 1800000.00),
(8, 8, '2026-03-28 08:53:37', 600000.00),
(9, 9, '2026-03-28 08:53:37', 400000.00),
(10, 1, '2026-03-28 08:53:37', 120000.00),
(11, 2, '2026-03-28 08:53:37', 2200000.00),
(12, 10, '2026-03-28 08:53:37', 550000.00),
(13, 4, '2026-03-28 08:53:37', 150000.00),
(14, 3, '2026-03-28 08:53:37', 1200000.00),
(15, 5, '2026-03-28 08:53:37', 300000.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 1, 15000000.00),
(2, 1, 2, 1, 500000.00),
(3, 2, 3, 3, 150000.00),
(4, 3, 5, 1, 1200000.00),
(5, 4, 8, 1, 2500000.00),
(6, 5, 11, 1, 350000.00),
(7, 6, 15, 1, 850000.00),
(8, 7, 14, 1, 1800000.00),
(9, 8, 19, 1, 600000.00),
(10, 9, 16, 1, 400000.00),
(11, 10, 12, 1, 120000.00),
(12, 11, 17, 1, 2200000.00),
(13, 12, 20, 1, 550000.00),
(14, 13, 3, 1, 150000.00),
(15, 14, 7, 1, 1200000.00),
(16, 15, 4, 1, 300000.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `category_id`, `stock`) VALUES
(1, 'Gaming Laptop', 15000000.00, 1, 15),
(2, 'Wireless Mouse', 500000.00, 1, 50),
(3, 'Cotton T-Shirt', 150000.00, 2, 100),
(4, 'Network Security Book', 300000.00, 3, 25),
(5, 'Mechanical Keyboard', 1200000.00, 1, 5),
(6, 'Uncategorized Widget', 50000.00, NULL, 50),
(7, 'Rubber Ducky USB', 1200000.00, 6, 8),
(8, 'WiFi Pineapple', 2500000.00, 6, 3),
(9, 'Running Shoes', 1500000.00, 5, 30),
(10, 'Yoga Mat', 250000.00, 5, 8),
(11, 'Desk Lamp', 350000.00, 4, 40),
(12, 'Coffee Mug', 120000.00, 4, 150),
(13, 'Jeans', 450000.00, 2, 60),
(14, 'Winter Jacket', 1800000.00, 2, 4),
(15, 'Bluetooth Speaker', 850000.00, 1, 12),
(16, 'Advanced Penetration Testing', 400000.00, 3, 20),
(17, 'Smart Watch', 2200000.00, 1, 7),
(18, 'Mystery Box', 999999.00, NULL, 0),
(19, 'Lockpicking Set', 600000.00, 6, 11),
(20, '100% Hacker Hoodie', 550000.00, 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `created_at`) VALUES
(1, 'Alice Smith', 'alice@example.com', '2026-03-28 08:53:36'),
(2, 'Bob Jones', 'bob@example.com', '2026-03-28 08:53:36'),
(3, 'Charlie Brown', 'charlie@example.com', '2026-03-28 08:53:36'),
(4, 'Diana Prince', 'diana@example.com', '2026-03-28 08:53:36'),
(5, 'Evan Wright', 'evan@example.com', '2026-03-28 08:53:36'),
(6, 'Fiona Gallagher', 'fiona@example.com', '2026-03-28 08:53:36'),
(7, '<script>alert(\"XSS\")</script> Test User', 'xss_tester@example.com', '2026-03-28 08:53:36'),
(8, 'Robert\'; DROP TABLE users;--', 'bobby_tables@example.com', '2026-03-28 08:53:36'),
(9, 'admin\" OR 1=1--', 'sqli_tester@example.com', '2026-03-28 08:53:36'),
(10, '<img src=x onerror=alert(1)>', 'xss_img@example.com', '2026-03-28 08:53:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
