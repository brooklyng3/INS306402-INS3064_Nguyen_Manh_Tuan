<?php
declare(strict_types=1);

$username = '';
$password = '';
$errors = [];
$isStep1Complete = false;

function sanitize(string $data): string {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? ''; // Do not sanitize passwords

    if (empty($username)) {
        $errors['username'] = "Please enter a username.";
    } elseif (strlen($username) < 3) {
        $errors['username'] = "Username must be at least 3 characters.";
    }

    if (empty($password)) {
        $errors['password'] = "Please enter a password.";
    } elseif (strlen($password) < 6) {
        $errors['password'] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        $isStep1Complete = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - Step 1</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Account Info</h2>
        <div class="progress-indicator">Step 1 of 2</div>

        <?php if ($isStep1Complete): ?>
            <div class="success-message">Step 1 validated successfully!</div>
            
            <form action="step2.php" method="POST">
                <input type="hidden" name="username" value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="password" value="<?= htmlspecialchars($password, ENT_QUOTES, 'UTF-8') ?>">
                
                <p>Click below to continue to profile setup.</p>
                <button type="submit" class="btn">Proceed to Step 2</button>
            </form>

        <?php else: ?>
            <form action="step1.php" method="POST" novalidate>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required minlength="3" 
                           value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>"
                           class="<?= isset($errors['username']) ? 'input-error' : '' ?>">
                    <?php if (isset($errors['username'])): ?>
                        <div class="error-message"><?= $errors['username'] ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required minlength="6" autocomplete="new-password" value=""
                           class="<?= isset($errors['password']) ? 'input-error' : '' ?>">
                    <?php if (isset($errors['password'])): ?>
                        <div class="error-message"><?= $errors['password'] ?></div>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn">Next Step</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>