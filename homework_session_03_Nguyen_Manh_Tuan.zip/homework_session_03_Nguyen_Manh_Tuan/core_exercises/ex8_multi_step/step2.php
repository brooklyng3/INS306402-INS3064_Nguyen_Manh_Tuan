<?php
declare(strict_types=1);

$errors = [];
$success = false;

// Retrieve hidden data passed from Step 1
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Redirect back to step 1 if accessed directly without data
if (empty($username) || empty($password)) {
    header('Location: step1.php');
    exit;
}

$bio = '';
$location = '';

function sanitize(string $data): string {
    return htmlspecialchars(stripslashes(trim($data)), ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['step2_submitted'])) {
    
    $bio = sanitize($_POST['bio'] ?? '');
    $location = sanitize($_POST['location'] ?? '');

    if (empty($bio)) {
        $errors['bio'] = "Please tell us a little about yourself.";
    }

    if (empty($location)) {
        $errors['location'] = "Please select your location.";
    }

    if (empty($errors)) {
        $success = true; 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - Step 2</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Profile Info</h2>
        <div class="progress-indicator">Step 2 of 2</div>

        <?php if ($success): ?> 
            <div class="success-message">Registration complete!</div>
            <h3>Your Submitted Data:</h3>
            <ul style="color: var(--text-secondary); line-height: 1.6;">
                <li><strong>Username:</strong> <?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?></li>
                <li><strong>Password:</strong> <?= htmlspecialchars($password, ENT_QUOTES, 'UTF-8') ?></li>
                <li><strong>Location:</strong> <?= htmlspecialchars($location, ENT_QUOTES, 'UTF-8') ?></li>
                <li><strong>Bio:</strong> <?= htmlspecialchars($bio, ENT_QUOTES, 'UTF-8') ?></li>
            </ul>
        <?php else: ?> 
            <form action="step2.php" method="POST" novalidate> 
                <input type="hidden" name="username" value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>"> 
                <input type="hidden" name="password" value="<?= htmlspecialchars($password, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="step2_submitted" value="1">

                <div class="form-group">
                    <label for="location">Location:</label>
                    <select id="location" name="location" required class="<?= isset($errors['location']) ? 'input-error' : '' ?>">
                        <option value="">-- Select a Location --</option>
                        <option value="Vietnam" <?= $location === 'Vietnam' ? 'selected' : '' ?>>Vietnam</option>
                        <option value="United States" <?= $location === 'United States' ? 'selected' : '' ?>>United States</option>
                        <option value="Other" <?= $location === 'Other' ? 'selected' : '' ?>>Other</option>
                    </select>
                    <?php if (isset($errors['location'])): ?>
                        <div class="error-message"><?= $errors['location'] ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="bio">Short Bio:</label>
                    <textarea id="bio" name="bio" rows="4" required
                              class="<?= isset($errors['bio']) ? 'input-error' : '' ?>"><?= htmlspecialchars($bio, ENT_QUOTES, 'UTF-8') ?></textarea>
                    <?php if (isset($errors['bio'])): ?>
                        <div class="error-message"><?= $errors['bio'] ?></div>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <a href="step1.php" class="btn" style="text-align: center; text-decoration: none; background-color: var(--border-color); color: var(--text-primary);">Restart</a>
                    <button type="submit" class="btn">Complete Registration</button> 
                </div>
            </form>
        <?php endif; ?> 
    </div>
</body>
</html>