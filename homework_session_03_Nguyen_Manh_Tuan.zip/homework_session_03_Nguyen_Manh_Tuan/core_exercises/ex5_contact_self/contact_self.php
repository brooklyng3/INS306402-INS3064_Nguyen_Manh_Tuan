<?php
declare(strict_types=1);

session_start(); 

$errors = [];
$successMessage = '';
$name = $email = $phone = $message = '';


if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    unset($_SESSION['success_message']); 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $name = htmlspecialchars(trim((string)($_POST['name'] ?? '')), ENT_QUOTES, 'UTF-8');
    $email = filter_var(trim((string)($_POST['email'] ?? '')), FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(trim((string)($_POST['phone'] ?? '')), ENT_QUOTES, 'UTF-8');
    $message = htmlspecialchars(trim((string)($_POST['message'] ?? '')), ENT_QUOTES, 'UTF-8');

    if (empty($name)) { $errors['name'] = "Please enter your full name."; }
    
    if (empty($email)) { $errors['email'] = "Please enter your email address."; } 
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors['email'] = "Please enter a valid email format."; }
    
    if (empty($phone)) { $errors['phone'] = "Please enter your phone number."; } 
    elseif (!preg_match('/^[0-9\+\-\s\(\)]+$/', $phone)) { $errors['phone'] = "Invalid phone number format."; }
    
    if (empty($message)) { $errors['message'] = "Please enter a message."; }

    if (empty($errors)) {
        $_SESSION['success_message'] = "Thank you, $name! Your message has been sent successfully.";
       
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit(); 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Contact Us</h2>

    <?php if ($successMessage): ?>
        <div class="alert success-message">
            <?= $successMessage ?>
        </div>
    <?php else: ?>
        <form action="contact_self.php" method="POST">
            
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" 
                       value="<?= $name ?>" 
                       class="<?= isset($errors['name']) ? 'input-error' : '' ?>" 
                       required>
                <?php if (isset($errors['name'])): ?>
                    <div class="error-text"><?= $errors['name'] ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" 
                       value="<?= $email ?>" 
                       class="<?= isset($errors['email']) ? 'input-error' : '' ?>" 
                       required>
                <?php if (isset($errors['email'])): ?>
                    <div class="error-text"><?= $errors['email'] ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number *</label>
                <input type="tel" id="phone" name="phone" 
                       value="<?= $phone ?>" 
                       class="<?= isset($errors['phone']) ? 'input-error' : '' ?>" 
                       required>
                <?php if (isset($errors['phone'])): ?>
                    <div class="error-text"><?= $errors['phone'] ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="message">Message *</label>
                <textarea id="message" name="message" rows="5" 
                          class="<?= isset($errors['message']) ? 'input-error' : '' ?>" 
                          required><?= $message ?></textarea>
                <?php if (isset($errors['message'])): ?>
                    <div class="error-text"><?= $errors['message'] ?></div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn-submit">Send Message</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>