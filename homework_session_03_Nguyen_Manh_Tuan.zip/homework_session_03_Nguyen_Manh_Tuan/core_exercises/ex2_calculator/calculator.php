<?php
declare(strict_types=1);

$result = "";
$error = "";
$equation = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $num1_raw = $_POST['num1'] ?? '';
    $num2_raw = $_POST['num2'] ?? '';
    $operation = $_POST['operation'] ?? '';

    if (!is_numeric($num1_raw) || !is_numeric($num2_raw)) {
        $error = "Please enter valid numeric values.";
    } else {
        $num1 = (float)$num1_raw;
        $num2 = (float)$num2_raw;

        switch ($operation) {
            case "add":
                $result = $num1 + $num2;
                $equation = "$num1 + $num2 = $result";
                break;
            case "subtract":
                $result = $num1 - $num2;
                $equation = "$num1 - $num2 = $result";
                break;
            case "multiply":
                $result = $num1 * $num2;
                $equation = "$num1 * $num2 = $result";
                break;
            case "divide":
                if ($num2 == 0) {
                    $error = "Error: Division by zero is not allowed.";
                } else {
                    $result = $num1 / $num2;
                    $equation = "$num1 / $num2 = $result";
                }
                break;
            default:
                $error = "Invalid operation selected.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Calculator - Dark Mode</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="calculator-container">
        <h2>Simple Calculator</h2>
        <form method="POST">
            <div class="input-group">
                <input type="number" step="any" name="num1" placeholder="First Number" required 
                       value="<?php echo isset($num1_raw) ? htmlspecialchars((string)$num1_raw) : ''; ?>">
            </div>
            
            <div class="input-group">
                <select name="operation">
                    <option value="add" <?php echo (isset($operation) && $operation == 'add') ? 'selected' : ''; ?>>+</option>
                    <option value="subtract" <?php echo (isset($operation) && $operation == 'subtract') ? 'selected' : ''; ?>>-</option>
                    <option value="multiply" <?php echo (isset($operation) && $operation == 'multiply') ? 'selected' : ''; ?>>×</option>
                    <option value="divide" <?php echo (isset($operation) && $operation == 'divide') ? 'selected' : ''; ?>>÷</option>
                </select>
            </div>

            <div class="input-group">
                <input type="number" step="any" name="num2" placeholder="Second Number" required 
                       value="<?php echo isset($num2_raw) ? htmlspecialchars((string)$num2_raw) : ''; ?>">
            </div>

            <button type="submit">Calculate</button>
        </form>

        <?php if ($equation !== ""): ?>
            <div class="result">Result: <strong><?php echo htmlspecialchars((string)$equation); ?></strong></div>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>