<?php
declare(strict_types=1);

$name = '';
$email = '';
$password = ''; // Added password variable
$errors = [];
$successMessage = '';

/**
 * Sanitizes input data to prevent XSS and ensure data integrity.
 */
function sanitizeInput(string $data): string {
    $data = trim($data);
    $data = stripslashes($data); 
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Retrieve and sanitize data. We do NOT sanitize passwords the same way 
    // because special characters are valid and necessary in passwords.
    $name = isset($_POST['name']) ? sanitizeInput((string)$_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitizeInput((string)$_POST['email']) : '';
    $password = $_POST['password'] ?? ''; 

    // Name Validation
    if (empty($name)) {
        $errors['name'] = "Please enter your full name."; 
    } elseif (strlen($name) < 2) {
        $errors['name'] = "Name must be at least 2 characters."; 
    }

    // Email Validation
    if (empty($email)) {
        $errors['email'] = "Please enter your email.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format."; 
    }

    // Password Validation (Meets the new requirement to force "Password too short")
    if (empty($password)) {
        $errors['password'] = "Please enter a password.";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "Password too short. Must be at least 8 characters.";
    }

    // If no errors exist
    if (empty($errors)) {
        $successMessage = "Registration successful, $name!";
        $name = $email = ''; // Clear sticky values on success
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Sticky Registration Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Create Account</h2>
    
    <?php if ($successMessage): ?>
        <div class="success-message"><?= htmlspecialchars($successMessage, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form action="sticky.php" method="POST" novalidate>
        
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" 
                   value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" 
                   class="<?= isset($errors['name']) ? 'error-border' : '' ?>" 
                   required minlength="2">
            <?php if (isset($errors['name'])): ?>
                <div class="error-text"><?= $errors['name'] ?></div> 
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" 
                   value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" 
                   class="<?= isset($errors['email']) ? 'error-border' : '' ?>" 
                   required>
            <?php if (isset($errors['email'])): ?>
                <div class="error-text"><?= $errors['email'] ?></div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" 
                   value="" 
                   autocomplete="new-password"
                   class="<?= isset($errors['password']) ? 'error-border' : '' ?>" 
                   required>
            <?php if (isset($errors['password'])): ?>
                <div class="error-text"><?= $errors['password'] ?></div>
            <?php endif; ?>
        </div>

        <button type="submit">Register</button> 
    </form>
</div>

</body>
</html>