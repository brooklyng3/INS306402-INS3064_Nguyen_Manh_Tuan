<?php
declare(strict_types=1);

/**
 * Sanitizes input data to prevent Cross-Site Scripting (XSS) and ensure safe processing.
 * This function performs three key cleaning steps: removing unnecessary whitespace, 
 * stripping backslashes, and converting special characters to HTML entities to safely 
 * modify data.
 *
 * @param string $data The raw input string from the user.
 * @return string The sanitized string safe for output or database use.
 */
function sanitize(string $data): string {
    $data = trim($data); 
    
    $data = stripslashes($data); 
    
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8'); 
    
    return $data;
}

/**
 * Validates whether a given string is a properly formatted email address.
 *
 * @param string $email The email string to validate.
 * @return bool True if the email format is valid, false otherwise.
 */
function validateEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false; 
}

/**
 * Validates if a string's length falls within a specified minimum and maximum range.
 *
 * @param string $str The string to check.
 * @param int $min The minimum allowed length.
 * @param int $max The maximum allowed length.
 * @return bool True if the string length is within the inclusive range, false otherwise.
 */
function validateLength(string $str, int $min, int $max): bool {
    $len = strlen($str); 
    
    return $len >= $min && $len <= $max;
}

/**
 * Validates password complexity requirements.
 * Enforces the rule: At least 8 characters, uppercase, lowercase, number, and a special character.
 *
 * @param string $password The password to check.
 * @return bool True if the password meets all complexity requirements, false otherwise.
 */
function validatePassword(string $password): bool {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z\d]).{8,}$/', $password) === 1;
}
?>