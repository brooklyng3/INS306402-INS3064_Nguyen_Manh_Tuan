<?php
declare(strict_types=1);

require_once 'utils.php';

/**
 * A simple helper function to format and output test results.
 */
function runTest(string $testName, bool $passed): void {
    $statusClass = $passed ? 'success-message' : 'error-message';
    $statusText = $passed ? 'PASS' : 'FAIL';
    
    echo "<li><strong>{$testName}</strong>: <span class='{$statusClass}'>{$statusText}</span></li>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Unit Tests: Validation Library</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Validation Library Tests</h1>
        <ul>
            <?php
            echo "<h3>sanitize()</h3>";
            runTest("Removes leading and trailing whitespace", sanitize("   test   ") === "test");
            runTest("Strips backslashes", sanitize("O\'Reilly") === "O&#039;Reilly");
            runTest("Neutralizes XSS payloads", sanitize("<script>alert('XSS')</script>") === "&lt;script&gt;alert(&#039;XSS&#039;)&lt;/script&gt;");

            echo "<h3>validateEmail()</h3>";
            runTest("Accepts valid email format", validateEmail("user@example.com") === true);
            runTest("Rejects email missing '@' symbol", validateEmail("userexample.com") === false);
            runTest("Rejects email missing domain", validateEmail("user@.com") === false);

            echo "<h3>validateLength()</h3>";
            runTest("Accepts string exactly at minimum boundary", validateLength("abc", 3, 10) === true);
            runTest("Accepts string exactly at maximum boundary", validateLength("abcdefghij", 3, 10) === true);
            runTest("Rejects string below minimum boundary", validateLength("ab", 3, 10) === false);
            runTest("Rejects string above maximum boundary", validateLength("abcdefghijk", 3, 10) === false);

            echo "<h3>validatePassword()</h3>";
            runTest("Accepts valid complex password with special char", validatePassword("StrongPass1!") === true);
            runTest("Rejects password that is too short", validatePassword("Str1!") === false);
            runTest("Rejects password missing uppercase letter", validatePassword("weakpass1!") === false);
            runTest("Rejects password missing number", validatePassword("StrongPass!") === false);
            runTest("Rejects password missing special character", validatePassword("StrongPass123") === false);
            ?>
        </ul>
    </div>
</body>
</html>