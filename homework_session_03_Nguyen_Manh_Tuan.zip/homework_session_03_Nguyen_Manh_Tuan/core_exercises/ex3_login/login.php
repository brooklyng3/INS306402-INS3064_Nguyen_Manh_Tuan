<?php
declare(strict_types=1);

$valid_username = 'admin';
$valid_password = '123456';

$username = '';
$message = '';
$message_class = '';
$failed_attempts = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    
    $failed_attempts = (int)($_POST['failed_attempts'] ?? 0);

    if (empty($username) || empty($password)) {
        $message = "Please enter both username and password.";
        $message_class = "error";
    } else {
        
        if ($username === $valid_username && $password === $valid_password) {
            $message = "Login successful! Welcome " . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . ".";
            $message_class = "success";
            $failed_attempts = 0; 
        } else {
            $failed_attempts++; 
            $message = "Invalid credentials. Failed attempts: " . $failed_attempts;
            $message_class = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>System Login</h2>
        
        <?php if ($message !== ''): ?>
            <div class="<?= $message_class ?>"><?= $message ?></div>
        <?php endif; ?>
        
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <input type="hidden" name="failed_attempts" value="<?= $failed_attempts ?>">
            
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>