<?php
declare(strict_types=1);

$errors = [];
$success = false;
$name = $email = $phone = $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $name = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '') {
        $errors[] = "Missing Data: Full Name is empty.";
    } elseif (strlen($name) < 2) {
        $errors[] = "Name must be at least 2 characters.";
    }

    if ($email === '') {
        $errors[] = "Missing Data: Email is empty.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($phone === '') {
        $errors[] = "Missing Data: Phone number is empty.";
    } elseif (!preg_match('/^[0-9\+\-\s]+$/', $phone)) {
        $errors[] = "Phone number contains invalid characters.";
    }

    if ($message === '') {
        $errors[] = "Missing Data: Message is empty.";
    }

    if (empty($errors)) {
        $success = true;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Submission Result</title>
    <link rel="stylesheet" href="style.css">
    </head>
<body>

    <?php if ($_SERVER['REQUEST_METHOD'] !== 'POST'): ?>
        <p>Please submit the form from the <a href="contact.html">Contact Page</a>.</p>
    
    <?php elseif ($success): ?>
        <div class="success-box">
            <h2>Thank You, <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>!</h2>
            <p>We have received your message details:</p>
            
            <ul class="data-list">
                <li><strong>Email:</strong> <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></li>
                <li><strong>Phone:</strong> <?= htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') ?></li>
                <li><strong>Message:</strong><br><?= nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8')) ?></li>
            </ul>
            
        </div>
        <a href="contact.html" class="back-link">← Go Back</a>

    <?php else: ?>
        <div class="error-box">
            <h2>❌ Submission Failed</h2>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <a href="javascript:history.back()" class="back-link">← Go Back and Fix</a>

    <?php endif; ?>

</body>
</html>