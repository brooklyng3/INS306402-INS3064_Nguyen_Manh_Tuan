<?php
declare(strict_types=1);

$searchQuery = '';
$displayMessage = '';
$errors = [];

if (isset($_GET['q'])) {
    
    $rawInput = (string)$_GET['q'];
    
    $searchQuery = htmlspecialchars($rawInput, ENT_QUOTES, 'UTF-8');
    
    if (empty(trim($rawInput))) {
        $errors[] = "Search query cannot be empty or just whitespace.";
    } elseif (strlen($rawInput) < 3) {
        $errors[] = "Search query must be at least 3 characters long.";
    } else {
        $displayMessage = "You searched for: " . $searchQuery;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Query Echo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Search Query Echo</h1>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($displayMessage): ?>
            <div class="alert alert-success">
                <p><?= $displayMessage ?></p>
            </div>
        <?php endif; ?>

        <form action="search.php" method="GET">
            <div class="form-group">
                <label for="q">Search Term:</label>
                <input 
                    type="text" 
                    id="q" 
                    name="q" 
                    value="<?= $searchQuery ?>" 
                    placeholder="Enter search term..."
                    required 
                    minlength="3"
                >
            </div>
            <button type="submit">Search</button>
        </form>

        <hr>

        
    </div>
</body>
</html>