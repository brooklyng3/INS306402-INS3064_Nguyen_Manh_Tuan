<?php
declare(strict_types=1); 
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];
$errors = [];
$successMessage = '';

$bio = $user['bio'] ?? '';
$avatarPath = $user['avatar'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['action']) && $_POST['action'] === 'logout') {
        session_destroy();
        header('Location: login.php');
        exit;
    }

    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $bio = trim($_POST['bio'] ?? '');
        $newAvatarPath = $avatarPath; 

        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                $fileTmpPath = $_FILES['avatar']['tmp_name'];
                $fileName = $_FILES['avatar']['name'];
                $fileNameParts = explode('.', $fileName);
                $fileExtension = strtolower(end($fileNameParts));

                $blockedExtensions = ['exe', 'pdf'];
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

                if (in_array($fileExtension, $blockedExtensions)) {
                    $errors['avatar'] = "Security Policy: Executable (.exe) and PDF (.pdf) files are strictly rejected.";
                } elseif (!in_array($fileExtension, $allowedExtensions)) {
                    $errors['avatar'] = "Invalid file format. Please upload a valid image file.";
                } else {
                    $uploadDir = 'uploads/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }
                    
                    $newFileName = uniqid('avatar_') . '.' . $fileExtension;
                    $destinationPath = $uploadDir . $newFileName;

                    if (move_uploaded_file($fileTmpPath, $destinationPath)) {
                        $newAvatarPath = $destinationPath;
                    } else {
                        $errors['avatar'] = "System error: Failed to save the uploaded image.";
                    }
                }
            } else {
                $errors['avatar'] = "An error occurred during file upload.";
            }
        }

        if (empty($errors)) {
            $_SESSION['user']['bio'] = $bio;
            $_SESSION['user']['avatar'] = $newAvatarPath;
            $avatarPath = $newAvatarPath;

            $usersFile = '../includes/users.json';
            
            if (file_exists($usersFile) && is_readable($usersFile) && is_writable($usersFile)) {
                $fileContent = file_get_contents($usersFile);
                if ($fileContent !== false) {
                    $users = json_decode($fileContent, true);
                    if (is_array($users)) {
                        foreach ($users as &$u) {
                            if ($u['username'] === $user['username']) {
                                $u['bio'] = $bio;
                                $u['avatar'] = $newAvatarPath;
                                break;
                            }
                        }
                        
                        if (file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT)) !== false) {
                            $successMessage = "Profile updated securely.";
                        } else {
                            $errors['general'] = "Failed to synchronize profile data to the database.";
                        }
                    }
                }
            } else {
                 $errors['general'] = "System error: Data repository is inaccessible.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }
        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--primary);
            margin: 0 auto 1.5rem auto;
            display: block;
            background-color: var(--input-bg);
        }
        .logout-btn {
            background-color: transparent;
            border: 1px solid var(--error);
            color: var(--error);
            width: auto;
            padding: 0.5rem 1rem;
        }
        .logout-btn:hover {
            background-color: rgba(239, 68, 68, 0.1);
        }
        textarea {
            width: 100%;
            padding: 0.75rem;
            border-radius: 6px;
            border: 1px solid var(--border);
            background-color: var(--input-bg);
            color: var(--text-color);
            resize: vertical;
            min-height: 100px;
        }
        textarea:focus {
            outline: none;
            border-color: var(--primary);
        }
        input[type="file"] {
            color: var(--text-muted);
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 600px;">
        
        <div class="dashboard-header">
            <h3>Welcome, <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8') ?></h3>
            
            <form action="profile.php" method="POST" style="margin: 0;">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>

        <?php if ($successMessage): ?>
            <div class="alert alert-success"><?= $successMessage ?></div>
        <?php endif; ?>

        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-error"><?= htmlspecialchars($errors['general'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form action="profile.php" method="POST" enctype="multipart/form-data" novalidate>
            <input type="hidden" name="action" value="update_profile">

            <div class="form-group" style="text-align: center;">
                <?php if (!empty($avatarPath) && file_exists($avatarPath)): ?>
                    <img src="<?= htmlspecialchars($avatarPath, ENT_QUOTES, 'UTF-8') ?>" alt="User Avatar" class="avatar-preview">
                <?php else: ?>
                    <div class="avatar-preview" style="display: flex; align-items: center; justify-content: center; color: var(--text-muted);">
                        No Image
                    </div>
                <?php endif; ?>
                
                <label for="avatar">Update Avatar</label>
                <input type="file" id="avatar" name="avatar" accept="image/png, image/jpeg, image/gif, image/webp">
                <?php if (isset($errors['avatar'])): ?>
                    <span class="error-text"><?= $errors['avatar'] ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="bio">System Biography (Bio)</label>
                <textarea id="bio" name="bio"><?= htmlspecialchars($bio, ENT_QUOTES, 'UTF-8') ?></textarea>
                <?php if (isset($errors['bio'])): ?>
                    <span class="error-text"><?= $errors['bio'] ?></span>
                <?php endif; ?>
            </div>

            <button type="submit">Update Profile</button>
        </form>

    </div>
</body>
</html>