<?php
declare(strict_types=1);
session_start(); 

if (isset($_SESSION['user'])) {
    header('Location: profile.php');
    exit;
}

$errors = [];
$username = '';
$isLocked = false;

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

if (isset($_SESSION['lockout_time'])) {
    if (time() < $_SESSION['lockout_time']) {
        $isLocked = true;
        $remainingSeconds = $_SESSION['lockout_time'] - time();
        $errors['general'] = "Account locked due to multiple failed attempts. Try again in " . ceil($remainingSeconds) . " seconds.";
    } else {
        $_SESSION['login_attempts'] = 0;
        unset($_SESSION['lockout_time']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isLocked) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username)) {
        $errors['username'] = "Username or Email is required.";
    }
    if (empty($password)) {
        $errors['password'] = "Password is required.";
    }

    if (empty($errors)) {
        $usersFile = '../includes/users.json';
        $authenticated = false;
        $userData = null;

        if (file_exists($usersFile) && is_readable($usersFile)) {
            $fileContent = file_get_contents($usersFile);
            if ($fileContent !== false) {
                $users = json_decode($fileContent, true);
                if (is_array($users)) {
                    foreach ($users as $user) {
                        if ($user['username'] === $username || $user['email'] === $username) {
                            if (password_verify($password, $user['password'])) {
                                $authenticated = true;
                                $userData = $user;
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            $errors['general'] = "System error: Cannot access identity records.";
        }

        if ($authenticated && $userData !== null) {
            $_SESSION['login_attempts'] = 0;
            unset($_SESSION['lockout_time']);
            
            $_SESSION['user'] = [
                'username' => $userData['username'],
                'email' => $userData['email'],
                'bio' => $userData['bio'] ?? '',
                'avatar' => $userData['avatar'] ?? ''
            ];
            
            header('Location: profile.php');
            exit;
        } else {
            $_SESSION['login_attempts']++;
            
            if ($_SESSION['login_attempts'] >= 3) {
                $_SESSION['lockout_time'] = time() + 300; 
                $errors['general'] = "Access denied. Maximum failed attempts reached. Account locked for 5 minutes.";
                $isLocked = true;
            } else {
                $remainingAttempts = 3 - $_SESSION['login_attempts'];
                $errors['general'] = "Invalid credentials. $remainingAttempts attempt(s) remaining.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <h2>System Access</h2>

        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-error"><?= htmlspecialchars($errors['general'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST" novalidate>
            <div class="form-group">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" 
                       value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" 
                       class="<?= isset($errors['username']) ? 'is-invalid' : '' ?>" 
                       <?= $isLocked ? 'disabled' : 'required' ?>>
                <?php if (isset($errors['username'])): ?>
                    <span class="error-text"><?= $errors['username'] ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" autocomplete="new-password"
                        class="<?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                        <?= $isLocked ? 'disabled' : 'required' ?>>
                <?php if (isset($errors['password'])): ?>
                    <span class="error-text"><?= $errors['password'] ?></span>
                <?php endif; ?>
            </div>

            <button type="submit" <?= $isLocked ? 'disabled style="background-color: var(--border); cursor: not-allowed;"' : '' ?>>
                <?= $isLocked ? 'System Locked' : 'Login' ?>
            </button>
        </form>

        <div class="link-text">
            New to the site? <a href="register.php">Register Account</a>
        </div>
    </div>
</body>
</html>