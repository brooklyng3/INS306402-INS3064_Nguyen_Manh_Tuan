<?php
declare(strict_types=1);
session_start();

if (isset($_SESSION['user'])) {
    header('Location: profile.php');
    exit;
}

$errors = [];
$successMessage = '';
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
    $username = trim($_POST['username'] ?? ''); 
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($username)) { 
        $errors['username'] = "Username is required.";
    } elseif (strlen($username) < 3) {
        $errors['username'] = "Username must be at least 3 characters.";
    }

    if (empty($email)) {
        $errors['email'] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
        $errors['email'] = "Invalid email format.";
    }

    if (empty($password)) {
        $errors['password'] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "Password must be at least 8 characters.";
    }

    if ($password !== $confirmPassword) {
        $errors['confirm_password'] = "Passwords do not match.";
    }

    if (empty($errors)) {
        $usersFile = '../includes/users.json';
        $users = [];

        if (file_exists($usersFile)) {
            $fileContent = file_get_contents($usersFile);
            if ($fileContent !== false) {
                $decoded = json_decode($fileContent, true);
                if (is_array($decoded)) {
                    $users = $decoded;
                }
            }
        }

        $userExists = false;
        foreach ($users as $user) {
            if ($user['email'] === $email || $user['username'] === $username) {
                $userExists = true;
                $errors['general'] = "A user with this email or username already exists.";
                break;
            }
        }

        if (!$userExists) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $users[] = [
                'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'), // 
                'email' => htmlspecialchars($email, ENT_QUOTES, 'UTF-8'),
                'password' => $hashedPassword,
                'bio' => '',
                'avatar' => ''
            ];

            if (file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT)) !== false) {
                $successMessage = "Registration successful! You can now log in.";
                $username = '';
                $email = '';
            } else {
                $errors['general'] = "Internal error: Could not save user data.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <h2>System Registration</h2>
        
        <?php if ($successMessage): ?>
            <div class="alert alert-success"><?= $successMessage ?></div>
        <?php endif; ?>

        <?php if (isset($errors['general'])): ?>
            <div class="alert alert-error"><?= $errors['general'] ?></div>
        <?php endif; ?>

        <form action="register.php" method="POST" novalidate>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" 
                       value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" 
                       class="<?= isset($errors['username']) ? 'is-invalid' : '' ?>" required minlength="3">
                <?php if (isset($errors['username'])): ?>
                    <span class="error-text"><?= $errors['username'] ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" 
                       value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" 
                       class="<?= isset($errors['email']) ? 'is-invalid' : '' ?>" required>
                <?php if (isset($errors['email'])): ?>
                    <span class="error-text"><?= $errors['email'] ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" 
                       class="<?= isset($errors['password']) ? 'is-invalid' : '' ?>" required minlength="8">
                <?php if (isset($errors['password'])): ?>
                    <span class="error-text"><?= $errors['password'] ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" 
                       class="<?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>" required>
                <?php if (isset($errors['confirm_password'])): ?>
                    <span class="error-text"><?= $errors['confirm_password'] ?></span>
                <?php endif; ?>
            </div>

            <button type="submit">Register</button>
        </form>

        <div class="link-text">
            Already registered? <a href="login.php">Login</a>
        </div>
    </div>
</body>
</html>