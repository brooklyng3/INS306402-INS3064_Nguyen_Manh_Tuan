# User Profile System - PHP Mini Project

A cohesive mini-application built with PHP that demonstrates fundamental concepts in routing, state management, form validation, and secure data handling. 

## 🚀 Features

* **Registration System:** Secure user registration with strict validation, password confirmation, and password hashing. Data is stored persistently without requiring a database.
* **Login & State Management:** Credential verification and session initialization using `session_start()`. Includes a lockout mechanism after 3 failed attempts.
* **Access Control:** Protected dashboard route. Unauthenticated users (e.g., accessing via Incognito mode) are automatically redirected to the login page.
* **Profile Editing:** Authenticated users can update their biography and upload a custom avatar. Forms are "sticky" and populate with existing data.
* **Custom Dark UI:** Fully styled responsive interface using a custom CSS dark theme.

## 🛡️ Security & Validation Highlights

This application was built with a strong focus on defensive programming and strict acceptance criteria:

* **Strict Typing:** Enforced using `declare(strict_types=1)`.
* **Error Handling:** Explicit checks (e.g., `file_exists`, `is_readable`) are used instead of the forbidden `@` suppression operator.
* **Dual-Layer Validation:** Implements both HTML5 client-side constraints and robust server-side validation.
* **XSS Protection:** All user-generated content, specifically the Bio field, is escaped using `htmlspecialchars` to neutralize cross-site scripting payloads.
* **Secure File Uploads:** Validates file extensions, explicitly rejecting executable (`.exe`) and document (`.pdf`) files. Uploads are renamed using `uniqid()` to prevent path traversal and overwriting.
* **Brute-Force Mitigation:** Login system tracks failed attempts and imposes a 5-minute lockout after 3 consecutive failures.
* **Data Isolation:** The simulated database (`users.json`) is kept outside the public directory to prevent direct URL access.

## 📂 Project Structure

```text
/mini_project/
├── assets/
│   └── style.css           # Dark theme styling and UI feedback
├── includes/
│   └── users.json          # Simulated database (ensure write permissions)
├── public/
│   ├── uploads/            # Auto-generated directory for user avatars
│   ├── login.php           # Authentication logic
│   ├── profile.php         # Protected dashboard and file upload handling
│   └── register.php        # Account creation logic
└── README.md