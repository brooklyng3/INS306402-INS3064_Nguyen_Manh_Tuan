<?php
declare(strict_types=1);

$methodUsed = $_SERVER['REQUEST_METHOD'];
$submittedData = [];
$errors = [];
$hasSubmitted = false;

if (isset($_REQUEST['submit_form'])) {
    $hasSubmitted = true;
    
    if ($methodUsed === 'POST') {
        $submittedData = $_POST;
    } elseif ($methodUsed === 'GET') {
        $submittedData = $_GET;
    }

    $secretData = trim((string)($submittedData['secret_data'] ?? ''));
    
    if (empty($secretData)) {
        $errors[] = "The Secret Data field cannot be empty.";
    } elseif (strlen($secretData) < 3) {
        $errors[] = "The Secret Data must be at least 3 characters long.";
    }

    if (empty($errors)) {
        $submittedData['secret_data'] = htmlspecialchars($secretData, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET vs POST Toggle</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>GET vs POST Data Visualization</h1>
    
    <?php if ($hasSubmitted && !empty($errors)): ?>
        <div class="error-box">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form id="payloadForm" action="method_toggle.php" method="GET">
        
        <div class="toggle-group">
            <p>Select Transmission Method:</p>
            <label>
                <input type="radio" name="method_choice" value="GET" checked onchange="updateFormMethod()"> 
                Send via GET
            </label>
            <label>
                <input type="radio" name="method_choice" value="POST" onchange="updateFormMethod()"> 
                Send via POST
            </label>
        </div>

        <div class="input-group">
            <label for="secret_data">Secret Data:</label>
            <input type="text" id="secret_data" name="secret_data" required minlength="3" placeholder="Enter payload here...">
        </div>

        <input type="hidden" name="submit_form" value="1">
        
        <button type="submit" class="btn">Transmit Data</button>
    </form>

    <?php if ($hasSubmitted && empty($errors)): ?>
        <div class="results-panel">
            <h2>Server Response Analysis</h2>
            <p><strong>Detected Method:</strong> <span class="highlight"><?= htmlspecialchars($methodUsed) ?></span></p>
            
            <h3>Superglobal Array Contents:</h3>
            <pre><code>
                    <?php
                    print_r($submittedData);
                    ?>
            </code></pre>
        </div>
    <?php endif; ?>
</div>

<script>
    /**
     * Dynamically changes the form's method attribute based on the selected radio button.
     */
    function updateFormMethod() {
        const form = document.getElementById('payloadForm');
        const selectedMethod = document.querySelector('input[name="method_choice"]:checked').value;
        form.method = selectedMethod;
        console.log("Form method updated to: " + form.method);
    }

    window.onload = updateFormMethod;
</script>

</body>
</html>