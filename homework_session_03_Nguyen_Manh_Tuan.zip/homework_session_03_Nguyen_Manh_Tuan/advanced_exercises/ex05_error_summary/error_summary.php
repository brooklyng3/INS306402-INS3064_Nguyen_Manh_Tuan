<?php
declare(strict_types=1); 

$errors = []; 

$name = ''; 
$email = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $name = trim((string)($_POST['name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    
    if (empty($name)) { 
        $errors['name'] = "Full Name is required.";
    } elseif (strlen($name) < 2) {
        $errors['name'] = "Name must be at least 2 characters long."; 
    }
    
    if (empty($email)) {
        $errors['email'] = "Email address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
        $errors['email'] = "Invalid email format.";
    }
    
    if (empty($errors)) { 
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error Summary Block</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Account Registration</h2>

    <?php if ($success): ?>
        <div class="success-alert">
            Account Registered successfully! Welcome, <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>.
        </div>
    <?php else: ?>

        <?php if (!empty($errors)): ?> <div class="error-summary">
                <strong>Please fix the following errors:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li> <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="error_summary.php" method="POST"> <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" 
                       value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" 
                       class="<?= isset($errors['name']) ? 'error' : '' ?>" 
                       required> </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" 
                       value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" 
                       class="<?= isset($errors['email']) ? 'error' : '' ?>" 
                       required> </div>

            <button type="submit">Submit Registration</button>
        </form>
        
    <?php endif; ?>
</div>

</body>
</html>