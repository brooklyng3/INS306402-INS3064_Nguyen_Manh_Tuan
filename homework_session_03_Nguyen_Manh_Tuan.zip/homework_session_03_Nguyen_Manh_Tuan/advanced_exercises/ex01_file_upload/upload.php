<?php
declare(strict_types=1);

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        
        $fileTmpPath = $_FILES['avatar']['tmp_name'];
        $fileSize = $_FILES['avatar']['size'];
        $maxSize = 2 * 1024 * 1024;
        
        if ($fileSize > $maxSize) {
            $message = "Upload failed: File exceeds the 2MB limit.";
            $messageType = "error";
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($fileTmpPath);
            
            $allowedMimeTypes = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png'
            ];
            
            if (!array_key_exists($mimeType, $allowedMimeTypes)) {
                $message = "Upload failed: Invalid file format. Only JPG and PNG are allowed.";
                $messageType = "error";
            } else {
                $extension = $allowedMimeTypes[$mimeType];
                $uniqueFilename = uniqid('avatar_', true) . '.' . $extension;
                
                $uploadDir = __DIR__ . '/uploads/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                $destinationPath = $uploadDir . $uniqueFilename;
                
                if (move_uploaded_file($fileTmpPath, $destinationPath)) {
                    $message = "Success: Avatar uploaded securely as {$uniqueFilename}.";
                    $messageType = "success";
                } else {
                    $message = "Upload failed: A server error occurred while saving the file.";
                    $messageType = "error";
                }
            }
        }
    } else {
        $errorCode = $_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE;
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
            UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the MAX_FILE_SIZE directive specified in the HTML form.',
            UPLOAD_ERR_PARTIAL    => 'The uploaded file was only partially uploaded.',
            UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
        ];
        
        $message = $errorMessages[$errorCode] ?? 'An unknown error occurred during the upload.';
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Avatar Upload</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Profile Avatar</h2>
        
        <?php if ($message): ?>
            <div class="alert alert-<?= htmlspecialchars($messageType) ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="avatar">Upload Avatar (Max 2MB):</label>
                <input type="file" id="avatar" name="avatar" accept="image/jpeg, image/png" required>
            </div>
            
            <button type="submit" class="btn">Upload</button>
        </form>
    </div>
</body>
</html>