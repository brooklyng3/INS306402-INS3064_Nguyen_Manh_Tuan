<?php
declare(strict_types=1);

session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        die("403 Forbidden");
    }
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';

    if (empty($username)) {
        $error = "Server validation failed: Username is required.";
    } else {
        $safe_username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $message = "Success! Received data for user: " . $safe_username;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSRF Protected Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Secure Data Submission</h2>
        
        <?php if ($error !== ''): ?>
            <div class="alert error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($message !== ''): ?>
            <div class="alert success"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" action="csrf_form.php">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required placeholder="Enter your username">
            </div>
            
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>