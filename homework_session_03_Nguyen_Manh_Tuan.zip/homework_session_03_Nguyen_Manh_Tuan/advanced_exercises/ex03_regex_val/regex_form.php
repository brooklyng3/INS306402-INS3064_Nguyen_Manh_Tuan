<?php
declare(strict_types=1);

$errors = [
    'username' => [],
    'password' => []
];
$success_message = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // 
    $username = trim($_POST['username'] ?? ''); // 
    $password = $_POST['password'] ?? '';

    if (empty($username)) {
        $errors['username'][] = "Username is required.";
    } elseif (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
        $errors['username'][] = "Username must contain only alphanumeric characters.";
    }
    if (empty($password)) {
        $errors['password'][] = "Password is required.";
    } else {
        if (!preg_match('/[A-Z]/', $password)) {
            $errors['password'][] = "Password missing uppercase letter.";
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors['password'][] = "Password missing lowercase letter.";
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors['password'][] = "Password missing number.";
        }
        if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
            $errors['password'][] = "Password missing symbol.";
        }
    }

    if (empty($errors['username']) && empty($errors['password'])) {
        $success_message = "Registration successful! Your credentials meet all security policies.";
        $username = '';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form-container">
    <h2>Secure Registration Form</h2>
    
    <?php if ($success_message): ?>
        <div class="success-message">
            <?= htmlspecialchars($success_message, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form action="regex_form.php" method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input 
                type="text" 
                id="username" 
                name="username" 
                value="<?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?>" 
                required 
                pattern="[a-zA-Z0-9]+" 
                title="Only alphanumeric characters allowed"
            >
            <?php if (!empty($errors['username'])): ?>
                <div class="error-group">
                    <?php foreach ($errors['username'] as $error): ?>
                        <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input 
                type="password" 
                id="password" 
                name="password" 
                autocomplete="new-password"
                required
            >
            <?php if (!empty($errors['password'])): ?>
                <div class="error-group">
                    <?php foreach ($errors['password'] as $error): ?>
                        <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>