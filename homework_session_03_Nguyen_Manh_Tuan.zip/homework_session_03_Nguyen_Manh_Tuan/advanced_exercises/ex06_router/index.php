<?php
declare(strict_types=1);

$page = $_GET['page'] ?? 'home';

$allowed_pages = ['home', 'about', 'contact'];

$file_path = 'pages/' . $page . '.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple PHP Router</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <a href="?page=home">Home</a>
            <a href="?page=about">About</a>
            <a href="?page=contact">Contact</a>
            <a href="?page=invalid">Test 404</a>
        </nav>
    </header>

    <main class="container">
        <?php
        if (in_array($page, $allowed_pages, true) && file_exists($file_path)) {
            include $file_path;
        } else {
            http_response_code(404);
            echo "<div class='error-page'>";
            echo "<h1>404 - Page Not Found</h1>";
            echo "<p>The requested route <code>" . htmlspecialchars($page, ENT_QUOTES, 'UTF-8') . "</code> does not exist.</p>";
            echo "</div>";
        }
        ?>
    </main>
</body>
</html>