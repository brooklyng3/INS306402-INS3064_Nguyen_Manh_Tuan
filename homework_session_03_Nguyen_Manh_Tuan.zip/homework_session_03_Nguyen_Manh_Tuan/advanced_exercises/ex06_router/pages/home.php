<?php
declare(strict_types=1);
?>

<div class="page-content">
    <h1>Welcome to the Simple Router</h1>
    
    <p>This is the default home page loaded by our Front Controller.</p>
    
    <p>By routing all requests through a central <code>index.php</code> file, we consolidate the application's entry point. This architecture reduces the overall attack surface and provides a single, easily auditable chokepoint to enforce security controls—like the strict whitelisting we implemented to prevent unauthorized file inclusion.</p>
    
    <h2>Available Routes</h2>
    <ul>
        <li><strong>Home</strong> (<code>?page=home</code>) - The current default view.</li>
        <li><strong>About</strong> (<code>?page=about</code>) - A placeholder for static content.</li>
        <li><strong>Contact</strong> (<code>?page=contact</code>) - The interactive form demonstrating robust data handling.</li>
    </ul>
</div>