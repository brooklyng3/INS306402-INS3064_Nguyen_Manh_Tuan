<?php
declare(strict_types=1);

$errors = [];
$successMessage = '';

$name = '';
$email = '';
$phone = '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');

    
    if (empty($name)) {
        $errors['name'] = "Full name is required.";
    }

    if (empty($email)) {
        $errors['email'] = "Email address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
        $errors['email'] = "Please provide a valid email format.";
    }

    
    if (empty($message)) {
        $errors['message'] = "Message cannot be empty.";
    }


    if (empty($errors)) {
        $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); 
        
        $successMessage = "Thank you, {$safeName}! Your message has been securely received.";
        
        $name = $email = $phone = $message = '';
    }
}
?>

<div class="page-content">
    <h1>Contact Us</h1>
    <p>Please fill out the form below. All fields marked with an asterisk (*) are required.</p>

    <?php if ($successMessage): ?>
        <div style="background-color: rgba(76, 175, 80, 0.1); color: #4caf50; padding: 1rem; border: 1px solid #4caf50; border-radius: 4px; margin-bottom: 1.5rem;">
            <?= $successMessage ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div style="background-color: rgba(207, 102, 121, 0.1); color: var(--error-color); padding: 1rem; border: 1px solid var(--error-color); border-radius: 4px; margin-bottom: 1.5rem;">
            <p style="margin-top: 0; font-weight: bold;">Please correct the following errors:</p>
            <ul style="margin-bottom: 0;">
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li> <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="?page=contact" method="POST" class="contact-form">
        
        <div style="margin-bottom: 1rem;">
            <label for="name">Full Name *</label><br>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" required 
                   style="width: 100%; max-width: 400px; padding: 0.5rem; background-color: #2d2d2d; color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; margin-top: 0.5rem;">
        </div>

        <div style="margin-bottom: 1rem;">
            <label for="email">Email Address *</label><br>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" required 
                   style="width: 100%; max-width: 400px; padding: 0.5rem; background-color: #2d2d2d; color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; margin-top: 0.5rem;">
        </div>
        
        <div style="margin-bottom: 1rem;">
            <label for="phone">Phone Number</label><br>
            <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') ?>" 
                   style="width: 100%; max-width: 400px; padding: 0.5rem; background-color: #2d2d2d; color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; margin-top: 0.5rem;">
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label for="message">Message *</label><br>
            <textarea id="message" name="message" rows="5" required 
                      style="width: 100%; max-width: 600px; padding: 0.5rem; background-color: #2d2d2d; color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; margin-top: 0.5rem; resize: vertical;"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>

        <button type="submit" style="background-color: var(--accent-color); color: #121212; border: none; padding: 0.75rem 1.5rem; font-size: 1rem; font-weight: bold; border-radius: 4px; cursor: pointer; transition: opacity 0.2s;">
            Send Message
        </button>
    </form>
</div>