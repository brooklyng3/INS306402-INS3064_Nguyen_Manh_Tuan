<?php
declare(strict_types=1);
?>

<div class="page-content">
    <h1>About Me</h1>
    
    <p>Hello! I am a developer and security researcher with a focus on building resilient systems and understanding the mechanics of vulnerabilities.</p>
    
    <h2>My Focus Areas</h2>
    <ul>
        <li><strong>Offensive Security:</strong> Exploring modern attack vectors to better understand how to defend against them.</li>
        <li><strong>AI Red Teaming:</strong> Investigating adversarial machine learning and the unique security challenges presented by AI models.</li>
        <li><strong>Secure Development:</strong> Writing clean, strictly typed code that minimizes attack surfaces from the ground up.</li>
    </ul>

    <p>This simple routing application demonstrates my ability to implement fundamental architectural patterns securely, avoiding common pitfalls like Path Traversal through strict file whitelisting.</p>
</div>