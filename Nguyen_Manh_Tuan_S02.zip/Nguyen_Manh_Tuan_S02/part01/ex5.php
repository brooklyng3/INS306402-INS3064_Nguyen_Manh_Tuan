<!DOCTYPE html>
<html>
<body>

<h2>Array Init Exercise</h2>

<form method="post">
    <label>Fruit 1:</label>
    <input type="text" name="fruit1" required><br><br>

    <label>Fruit 2:</label>
    <input type="text" name="fruit2" required><br><br>

    <label>Fruit 3:</label>
    <input type="text" name="fruit3" required><br><br>

    <input type="submit" value="Create Array">
</form>

<hr>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $f1 = $_POST['fruit1'];
    $f2 = $_POST['fruit2'];
    $f3 = $_POST['fruit3'];

    $fruitArray = [$f1, $f2, $f3];
    echo  $fruitArray[1];
}
?>

</body>
</html>