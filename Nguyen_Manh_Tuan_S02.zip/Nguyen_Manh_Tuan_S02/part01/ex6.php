<?php
$sentence = "";
$sentence .= "Brooklyn";
$sentence .= " is";
$sentence .= " handsome";

echo $sentence;
?>