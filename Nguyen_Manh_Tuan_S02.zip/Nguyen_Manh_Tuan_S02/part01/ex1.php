<!DOCTYPE html>
<html>
<body>

<form method="post">
    Name: <input type="text" name="name"><br>
    City: <input type="text" name="city"><br>
    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $city = $_POST['city'];
    
    echo "<h3>" . $name . " lives in " . $city . ".</h3>";
}
?>

</body>
</html>