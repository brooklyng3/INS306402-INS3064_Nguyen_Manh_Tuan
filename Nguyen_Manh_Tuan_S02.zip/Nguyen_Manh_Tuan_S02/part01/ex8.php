<!DOCTYPE html>
<html>
<body>

<form method="post">
    Age: <input type="number" name="age" min=0 max=100><br>
    Has ticket: <input type="checkbox" name="hasTicket"><br>
    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $age = $_POST['age'];
    $hasTicket = isset($_POST['hasTicket']) ? 1 : 0;
    if ($age >= 18 && $hasTicket) {
        echo "Enter";
    } else {
        echo "Do not enter";
    }
}
?>

</body>
</html>