<?php
$int = 5;
$str = '5';

$equal = ($int == $str);

$identical = ($int === $str);

echo "Equal (==): " . ($equal ? 'True' : 'False') . ", ";
echo "Identical (===): " . ($identical ? 'True' : 'False');
?>