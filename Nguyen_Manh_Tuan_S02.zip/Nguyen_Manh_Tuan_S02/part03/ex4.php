<?php
function safeDiv(float $a, float $b): ?float {
    if ($b == 0) {
        return null;
    }
    return $a / $b;
}

$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $num1 = isset($_POST['num1']) ? floatval($_POST['num1']) : 0;
    $num2 = isset($_POST['num2']) ? floatval($_POST['num2']) : 0;
    $result = safeDiv($num1, $num2);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Safe Division Calculator</title>
</head>
<body>
    <h1>Safe Division Calculator</h1>
    
    <form method="POST">
        <label for="num1">First Number:</label>
        <input type="number" id="num1" name="num1" step="0.01" required>
        
        <label for="num2">Second Number:</label>
        <input type="number" id="num2" name="num2" step="0.01" required>
        
        <button type="submit">Divide</button>
    </form>
    
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <h2>Result:</h2>
        <?php if ($result === null): ?>
            <p>null</p>
        <?php else: ?>
            <p>Result: <strong><?php echo $result; ?></strong></p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>