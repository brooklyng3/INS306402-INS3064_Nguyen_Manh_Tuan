<?php
function fmt(float $amt, string $c = '$'): string {
    return $c . number_format($amt, 2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST['amount'] ?? '';
    
    if ($input === '' || !is_numeric($input) || (float)$input < 0) {
        $error = 'Please enter a valid number';
        $result = null;
    } else {
        $result = fmt((float)$input);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Format Price</title>
</head>
<body>
    <h1>Format Price</h1>
    
    <form method="post">
        <label for="amount">Amount:</label>
        <input type="text" id="amount" name="amount" required>
        <button type="submit">Format</button>
    </form>
    
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    
    <?php if (isset($result)): ?>
        <p><strong><?php echo htmlspecialchars($result); ?></strong></p>
    <?php endif; ?>
</body>
</html>