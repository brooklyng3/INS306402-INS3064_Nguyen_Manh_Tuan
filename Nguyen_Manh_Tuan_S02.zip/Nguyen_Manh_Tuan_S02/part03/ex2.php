<?php
function area(float $w, float $h): float {
    if ($w <= 0 || $h <= 0) {
        throw new InvalidArgumentException('Width and height must be positive numbers');
    }
    return $w * $h;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $width = isset($_POST['width']) ? (float)$_POST['width'] : 0;
    $height = isset($_POST['height']) ? (float)$_POST['height'] : 0;
    
    try {
        $result = area($width, $height);
        $output = "Area: " . $result;
    } catch (InvalidArgumentException $e) {
        $output = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rectangle Area Calculator</title>
</head>
<body>
    <h1>Rectangle Area Calculator</h1>
    <form method="POST">
        <label>Width: <input type="number" name="width" step="0.1" required></label><br>
        <label>Height: <input type="number" name="height" step="0.1" required></label><br>
        <button type="submit">Calculate</button>
    </form>
    
    <?php if (isset($output)): ?>
        <p><?php echo htmlspecialchars($output); ?></p>
    <?php endif; ?>
</body>
</html>