<!DOCTYPE html>
<html>
<body>
    <form method="POST">
        <input type="text" name="name" placeholder="Enter your name" required>
        <button type="submit">Greet</button>
    </form>
</body>

<?php
function greet(string $name): string {
    if (empty(trim($name))) {
        return "Hello, Guest!";
    }
    
    return "Hello, " . htmlspecialchars(trim($name)) . "!";
}

// Example usage
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $input = $_POST['name'];
    echo greet($input);
}
?>