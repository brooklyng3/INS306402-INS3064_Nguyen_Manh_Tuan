<?php
function isAdult(?int $age): bool {
    if ($age === null) {
        return false;
    }
    
    if ($age < 0) {
        return false;
    }
    
    return $age >= 18;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputAge = isset($_POST['age']) && $_POST['age'] !== '' ? (int)$_POST['age'] : null;
    $result = isAdult($inputAge);
    $output = $result ? 'True' : 'False';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Age Check</title>
</head>
<body>
    <h1>Check if Adult</h1>
    
    <form method="POST">
        <label for="age">Enter Age:</label>
        <input type="number" id="age" name="age" placeholder="Leave empty for null" min=0>
        <button type="submit">Check</button>
    </form>
    
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <p><strong>Result:</strong> <?php echo htmlspecialchars($output); ?></p>
    <?php endif; ?>
</body>
</html>