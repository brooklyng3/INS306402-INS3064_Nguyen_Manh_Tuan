<?php
function calculateBMI(float $kg, float $m): array {
    if ($kg <= 0 || $m <= 0) {
        return ['error' => 'Weight and height must be positive numbers'];
    }
    
    $bmi = $kg / ($m * $m);
    
    if ($bmi < 18.5) {
        $category = 'Under';
    } elseif ($bmi < 25) {
        $category = 'Normal';
    } else {
        $category = 'Over';
    }
    
    return [
        'bmi' => round($bmi, 1),
        'category' => $category
    ];
}

$result = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kg = isset($_POST['weight']) ? floatval($_POST['weight']) : null;
    $m = isset($_POST['height']) ? floatval($_POST['height']) : null;
    
    if ($kg === null || $m === null) {
        $error = 'Please enter both weight and height';
    } else {
        $result = calculateBMI($kg, $m);
        $error = $result['error'] ?? null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMI Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 15px;
            font-weight: bold;
            color: #555;
        }
        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #e8f5e9;
            border-left: 4px solid #4caf50;
            border-radius: 4px;
        }
        .error {
            background-color: #ffebee !important;
            border-left-color: #f44336 !important;
            color: #c62828;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>BMI Calculator</h1>
        <form method="POST">
            <label for="weight">Weight (kg):</label>
            <input type="number" id="weight" name="weight" step="0.1" required>
            
            <label for="height">Height (m):</label>
            <input type="number" id="height" name="height" step="0.01" required>
            
            <button type="submit">Calculate BMI</button>
        </form>
        
        <?php if ($error): ?>
            <div class="result error">
                Error: <?php echo htmlspecialchars($error); ?>
            </div>
        <?php elseif ($result && !isset($result['error'])): ?>
            <div class="result">
                <strong>BMI: <?php echo $result['bmi']; ?> (<?php echo htmlspecialchars($result['category']); ?>)</strong>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>