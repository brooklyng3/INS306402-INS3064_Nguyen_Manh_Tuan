<?php
function formatGrade(int $grade): string {
    if ($grade < 0 || $grade > 100) {
        return '<span style="color: red;">Invalid</span>';
    }
    
    $color = match(true) {
        $grade >= 90 => 'green',
        $grade >= 80 => 'blue',
        $grade >= 70 => 'orange',
        default => 'red'
    };
    
    return "<span style=\"color: {$color};\">{$grade}</span>";
}

function renderStudentTable(array $students): string {
    if (empty($students)) {
        return '<p>No students to display.</p>';
    }
    
    $html = '<table border="1" cellpadding="10" cellspacing="0" style="border-collapse: collapse;">';
    $html .= '<thead><tr><th>Name</th><th>Grade</th></tr></thead><tbody>';
    
    foreach ($students as $student) {
        $name = htmlspecialchars($student['name'] ?? 'Unknown', ENT_QUOTES, 'UTF-8');
        $grade = $student['grade'] ?? null;
        
        if ($grade === null || !is_numeric($grade)) {
            $gradeDisplay = '<span style="color: red;">N/A</span>';
        } else {
            $gradeDisplay = formatGrade((int)$grade);
        }
        
        $html .= "<tr><td>{$name}</td><td>{$gradeDisplay}</td></tr>";
    }
    
    $html .= '</tbody></table>';
    return $html;
}

$students = [
    ['name' => 'Alice', 'grade' => 95],
    ['name' => 'Bob', 'grade' => 87],
    ['name' => 'Charlie', 'grade' => 72],
    ['name' => 'Diana', 'grade' => 88],
    ['name' => 'Eve', 'grade' => 65]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grades</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        table {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        th {
            background-color: #4CAF50;
            color: white;
            text-align: left;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Student List</h1>
    <?php echo renderStudentTable($students); ?>
</body>
</html>