<?php
function calculateStats(array $scores): array {
    if (empty($scores)) {
        return ['average' => 0, 'max' => 0, 'min' => 0];
    }
    
    return [
        'average' => array_sum($scores) / count($scores),
        'max' => max($scores),
        'min' => min($scores)
    ];
}

function filterTopScores(array $scores, float $threshold): array {
    return array_filter($scores, fn(int $score) => $score > $threshold);
}

$result = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['scores'])) {
    try {
        $input = trim($_POST['scores']);
        
        if (empty($input)) {
            $error = "Please enter scores.";
        } else {
            $scores = array_map('intval', explode(',', $input));
            $scores = array_filter($scores, fn($val) => $val !== 0 || $val === '0');
            
            if (empty($scores)) {
                $error = "No valid scores found.";
            } else {
                $stats = calculateStats($scores);
                $topScores = array_values(filterTopScores($scores, $stats['average']));
                $result = sprintf(
                    "Avg: %.2f, Top: [%s]",
                    $stats['average'],
                    implode(', ', $topScores)
                );
            }
        }
    } catch (Throwable $e) {
        $error = "Error processing scores: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Score Statistics</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
        }
        input, button {
            padding: 10px;
            margin: 10px 0;
            font-size: 16px;
        }
        input {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            color: #155724;
        }
        .error {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            color: #721c24;
        }
        .help {
            margin-top: 15px;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Score Statistics</h1>
        <form method="POST">
            <label for="scores">Enter scores (comma-separated integers):</label>
            <input type="text" id="scores" name="scores" placeholder="e.g., 65, 75, 80, 90, 95" required>
            <button type="submit">Calculate</button>
        </form>
        
        <?php if ($result): ?>
            <div class="result"><?php echo htmlspecialchars($result); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <div class="help">
            <strong>Example:</strong> 65, 75, 80, 90, 95
        </div>
    </div>
</body>
</html>