<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Primes 1-100</title>
    <style>
        body{font-family:Arial,Helvetica,sans-serif;padding:1rem;background:#f7f7f7;color:#111}
        .card{background:#fff;padding:1rem 1.25rem;border-radius:6px;max-width:600px;margin:2rem auto;box-shadow:0 2px 6px rgba(0,0,0,.08)}
        .title{font-weight:600;margin-bottom:.5rem}
        .output{font-family:monospace;color:#0b5394}
    </style>
</head>
<body>
    <div class="card">
        <div class="title">Prime numbers between 1 and 100</div>
        <div class="output">
        <?php
        function isPrime(int $n): bool {
                if ($n < 2) {
                        return false;
                }
                if ($n === 2) {
                        return true;
                }
                if ($n % 2 === 0) {
                        return false;
                }
                $limit = (int) floor(sqrt($n));
                for ($i = 3; $i <= $limit; $i += 2) {
                        if ($n % $i === 0) {
                                return false;
                        }
                }
                return true;
        }

        $primes = [];
        for ($i = 1; $i <= 100; $i++) {
                if (isPrime($i)) {
                        $primes[] = (string)$i;
                }
        }

        echo $primes ? implode(', ', $primes) : 'No primes found.';
        ?>
        </div>
    </div>
</body>
</html>