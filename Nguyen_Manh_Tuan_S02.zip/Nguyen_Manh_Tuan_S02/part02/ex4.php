<!DOCTYPE html>
<html>
<body>


<form method="post">
    <input type="text" name="price_string" placeholder="10, 20, 5" required>
    <input type="submit" value="Calculate Total">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $raw_input = $_POST['price_string'];


    $prices = explode(',', string: $raw_input);

    $prices = array_map('trim', $prices);

    $sum = 0;
    foreach ($prices as $price) {
        if (is_numeric($price)) {
            $sum += $price;
        }
    }

    echo "<h3>Total: " . $sum . "</h3>";
  
}
?>

</body>
</html>