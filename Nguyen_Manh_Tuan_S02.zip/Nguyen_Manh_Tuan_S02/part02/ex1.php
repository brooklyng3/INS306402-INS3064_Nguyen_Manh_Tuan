<!DOCTYPE html>
<html>
<body>

<form method="post">
    Grade: <input type="number" name="grade" min=0 max=100><br>
    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grade = $_POST['grade'];
    if ($grade >= 90) {
        echo "Grade: A";
    } elseif ($grade >= 80) {
        echo "Grade: B";
    } elseif ($grade >= 70) {
        echo "Grade: C";
    } else {
        echo "Grade: F";
    }
}
?>

</body>
</html>