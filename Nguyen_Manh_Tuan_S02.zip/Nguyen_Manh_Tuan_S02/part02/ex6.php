<?php
for ($i = 1; $i <= 20; $i++) {
    if ($i % 2 == 0) {
        if ($i==20) {
            echo $i . ".";
        } 
        else {
        echo $i . ", ";
        }
    }
}
?>