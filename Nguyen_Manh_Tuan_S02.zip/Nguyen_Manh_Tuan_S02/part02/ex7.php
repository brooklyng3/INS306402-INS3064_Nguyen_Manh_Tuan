<?php
$input = [];
$reversed = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Explode and trim
    $raw_items = explode(',', $_POST['numbers']);
    
    foreach ($raw_items as $item) {
        $trimmed = trim($item);
        
        // 2. Validate if the item is a valid float/int
        if (filter_var($trimmed, FILTER_VALIDATE_FLOAT) !== false) {
            $input[] = $trimmed;
        } else {
            $errors[] = "Invalid number detected: " . htmlspecialchars($trimmed);
        }
    }

    // 3. Only reverse if all items were valid
    if (empty($errors)) {
        for ($i = count($input) - 1; $i >= 0; $i--) {
            $reversed[] = $input[$i];
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Array Reversal</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        input { padding: 5px; width: 300px; }
        button { padding: 5px 15px; }
        .result { margin-top: 20px; padding: 10px; background: #f0f0f0; }
    </style>
</head>
<body>
    <h1>Array reverse</h1>
    <form method="POST">
        <label>Enter numbers (comma-separated):</label><br><br>
        <input type="text" name="numbers" placeholder="1, 2, 3, 4, 5" required>
        <button type="submit">Reverse</button>
    </form>
    
    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <?php if (!empty($errors)): ?>
            <div class="result">
                <h3>Errors:</h3>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php else: ?>
            <div class="result">
                <p><strong>Input:</strong> <?php echo implode(', ', $input); ?></p>
                <p><strong>Reversed:</strong> <?php echo implode(', ', $reversed); ?></p>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>