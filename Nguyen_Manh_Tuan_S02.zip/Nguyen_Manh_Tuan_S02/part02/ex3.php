<?php
echo "<table border='1' cellpadding='10'>";
echo "<tr><th></th>";
//th tag is header cell in a table
// Header row
for ($i = 1; $i <= 5; $i++) {
    echo "<th>$i</th>";
}
echo "</tr>";

// Multiplication grid
for ($i = 1; $i <= 5; $i++) {
    echo "<tr><th>$i</th>";
    for ($j = 1; $j <= 5; $j++) {
        echo "<td>" . ($i * $j) . "</td>";
    }
    echo "</tr>";
}

echo "</table>";
?>