<?php
$num = 10;

while ($num >= 1) {
    echo $num;
    if ($num > 1) {
        echo ", ";
    }
    $num--;
}

echo ", Liftoff!";
?>